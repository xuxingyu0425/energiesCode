"""Draw the WTBD experimental workflow.

SVG retains editable text. PDF embeds TrueType text. PNG is exported at 600 dpi."""
from __future__ import annotations

import json
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, ElementTree

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle
from matplotlib.path import Path as MplPath
from matplotlib import font_manager

OUT = Path(__file__).resolve().parent
PT_PER_MM = 72 / 25.4
WIDTH = 184.6 * PT_PER_MM
FONT = "Arial"
INK = "#1c3444"
EDGE = "#708898"
FLOW = "#3a586e"
BLUE = "#eaf2f7"
PALE = "#f5f7f8"
MODULE = "#dcebf4"
ACCENT = "#fce8cd"
ORANGE = "#b67826"

plt.rcParams.update({"font.family": FONT, "font.size": 9,
                     "pdf.fonttype": 42, "ps.fonttype": 42,
                     "svg.fonttype": "none", "savefig.facecolor": "white"})


class Diagram:
    def __init__(self, name, height):
        self.name, self.height = name, height
        self.fig = plt.figure(figsize=(WIDTH / 72, height / 72), dpi=72)
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.ax.set(xlim=(0, WIDTH), ylim=(height, 0))
        self.ax.axis("off")
        self.root = Element("svg", {"xmlns": "http://www.w3.org/2000/svg",
                            "width": "184.6mm", "height": f"{height / PT_PER_MM:.5f}mm",
                            "viewBox": f"0 0 {WIDTH:.6f} {height:.6f}"})
        SubElement(self.root, "rect", {"x": "0", "y": "0", "width": str(WIDTH),
                   "height": str(height), "fill": "white"})
        defs = SubElement(self.root, "defs")
        marker = SubElement(defs, "marker", {"id": "arrow", "markerWidth": "6",
            "markerHeight": "6", "refX": "6", "refY": "3", "orient": "auto",
            "markerUnits": "userSpaceOnUse", "viewBox": "0 0 6 6"})
        SubElement(marker, "path", {"d": "M 0 0 L 6 3 L 0 6 Z", "fill": FLOW})
        self.text_records = []
        self.components = []

    def text(self, x, y, text, size=9, weight="normal", anchor="middle", group=None):
        parent = group if group is not None else self.root
        node = SubElement(parent, "text", {"x": str(x), "y": str(y),
             "font-family": "Arial, Helvetica, sans-serif", "font-size": f"{size}pt",
             "font-weight": weight, "fill": INK, "text-anchor": anchor,
             "dominant-baseline": "central"})
        node.text = text
        artist = self.ax.text(x, y, text, fontsize=size, fontweight=weight,
                              ha={"middle": "center", "start": "left", "end": "right"}[anchor],
                              va="center", color=INK)
        self.text_records.append((text, size, artist))
        return artist

    def box(self, ident, x, y, w, h, lines, fill=BLUE, border=EDGE,
            size=9, lineheight=10.6, sizes=None):
        group = SubElement(self.root, "g", {"id": ident})
        SubElement(group, "rect", {"x": str(x), "y": str(y), "width": str(w),
            "height": str(h), "fill": fill, "stroke": border,
            "stroke-width": "0.9"})
        patch = Rectangle((x, y), w, h, facecolor=fill, edgecolor=border, linewidth=.9)
        self.ax.add_patch(patch)
        center = y + h / 2
        arts = []
        for i, line in enumerate(lines):
            arts.append(self.text(x + w / 2, center + (i - (len(lines) - 1) / 2) * lineheight,
                                 line, size=(sizes[i] if sizes else size), group=group))
        self.components.append(dict(id=ident, x=x, y=y, w=w, h=h, text_artists=arts))

    def arrow(self, ident, points, width=1.05):
        path = "M " + " L ".join(f"{x},{y}" for x, y in points)
        SubElement(self.root, "path", {"id": ident, "d": path, "fill": "none",
            "stroke": FLOW, "stroke-width": str(width), "stroke-linejoin": "round",
            "marker-end": "url(#arrow)"})
        p = MplPath(points, [MplPath.MOVETO] + [MplPath.LINETO] * (len(points) - 1))
        self.ax.add_patch(FancyArrowPatch(path=p, arrowstyle="-|>,head_length=4,head_width=2",
                                         mutation_scale=1, linewidth=width, color=FLOW,
                                         shrinkA=0, shrinkB=0, capstyle="round", joinstyle="round"))

    def connector(self, ident, points, width=1.05):
        """Undirected trunk of a branching or converging directed flow."""
        path = "M " + " L ".join(f"{x},{y}" for x, y in points)
        SubElement(self.root, "path", {"id": ident, "d": path, "fill": "none",
            "stroke": FLOW, "stroke-width": str(width), "stroke-linejoin": "round"})
        self.ax.plot([p[0] for p in points], [p[1] for p in points],
                     color=FLOW, linewidth=width, solid_capstyle="round")

    def dot(self, x, y):
        SubElement(self.root, "circle", {"cx": str(x), "cy": str(y), "r": "1.5", "fill": FLOW})
        self.ax.add_patch(plt.Circle((x, y), 1.5, color=FLOW, linewidth=0))

    def export(self):
        self.fig.canvas.draw()
        renderer = self.fig.canvas.get_renderer()
        problems = []
        for c in self.components:
            for a in c["text_artists"]:
                bb = a.get_window_extent(renderer=renderer)
                xy = self.ax.transData.inverted().transform(bb.get_points())
                xmin, xmax = sorted(xy[:, 0]); ymin, ymax = sorted(xy[:, 1])
                if xmin < c["x"] + 3 or xmax > c["x"] + c["w"] - 3 or ymin < c["y"] + 2 or ymax > c["y"] + c["h"] - 2:
                    problems.append(dict(component=c["id"], text=a.get_text(), bbox=[xmin, ymin, xmax, ymax]))
        assert not problems, problems
        ElementTree(self.root).write(OUT / f"{self.name}.svg", encoding="utf-8", xml_declaration=True)
        self.fig.savefig(OUT / f"{self.name}.pdf", dpi=600, pad_inches=0)
        # A slight rendering margin prevents pixel rounding below 600 effective dpi.
        self.fig.savefig(OUT / f"{self.name}.png", dpi=600.1, pad_inches=0)
        from PIL import Image
        png_path = OUT / f"{self.name}.png"
        with Image.open(png_path) as image:
            rgb = image.convert("RGB")
            rgb.save(png_path, dpi=(600.1, 600.1))
        self.fig.savefig(OUT / f"{self.name}_preview.png", dpi=150, pad_inches=0)
        qa = dict(width_mm=184.6, height_mm=self.height / PT_PER_MM,
                  minimum_font_pt=min(s for _, s, _ in self.text_records),
                  maximum_font_pt=max(s for _, s, _ in self.text_records),
                  live_SVG_text=True, PDF_font_type=42, PNG_dpi=600.1,
                  font=FONT, font_file=font_manager.findfont(FONT),
                  component_text_containment_passed=True,
                  text_labels=[t for t, _, _ in self.text_records])
        (OUT / f"{self.name}_qa.json").write_text(json.dumps(qa, indent=2), encoding="utf-8")
        plt.close(self.fig)


def experiment():
    d = Diagram("fig2_experimental_workflow",612)
    d.box("dataset",140,10,243,46,["WTBD: 1,065 images, annotations A and B","750 perceptual-hash groups"],size=9.2,lineheight=12)
    d.text(15,68,"Group-preserving data split",9.5,"bold","start")
    for ident,x,title,count in [("train",16,"Training","744 images"),("validation",187,"Validation","160 images"),("test",358,"Test","161 images")]:
        d.box("split_"+ident,x,90,150,40,[title,count],size=9.5,lineheight=12)
    d.connector("dataset_to_split",[(261.5,56),(261.5,74)])
    d.connector("split_branch",[(91,74),(433,74)])
    for ident,x in [("training",91),("validation",261.5),("test",433)]:
        d.arrow("split_to_"+ident,[(x,74),(x,90)])
    d.dot(261.5,74)
    d.box("training",140,153,243,66,["COCO initialization; 200 epochs","768 × 768; AdamW; batch 16","9 configurations × 5 seeds (45 runs)"],size=9.2,lineheight=12)
    d.arrow("training_images_to_training",[(91,130),(91,186),(140,186)])
    d.connector("training_to_weights",[(261.5,219),(261.5,227)])
    d.connector("checkpoint_branch",[(135,227),(391.5,227)])
    d.dot(261.5,227)
    d.box("fixed_epoch200",16,243,238,42,["Epoch 200: fixed weights","Primary comparison"],size=9.2,lineheight=12)
    d.box("validation_best",276,243,231,42,["Native best checkpoint","Validation AP50–95","Common fused annotations"],size=9.0,lineheight=11)
    d.arrow("weights_to_fixed",[(135,227),(135,243)])
    d.arrow("weights_to_best",[(391.5,227),(391.5,243)])
    d.box("thresholds",16,320,238,64,["Epoch-200 operating thresholds","8 configurations × 5 seeds (40 runs)","Excludes B-only; original A validation","Grid 0.01–0.99; maximize F1 and lock"],size=8.8,lineheight=12)
    d.arrow("fixed_weights_to_thresholds",[(135,285),(135,320)])
    d.connector("validation_trunk",[(261.5,130),(261.5,141),(516,141),(516,352)])
    d.dot(516,264)
    d.arrow("validation_to_best",[(516,264),(507,264)])
    d.arrow("A_validation_to_thresholds",[(516,352),(254,352)])
    # Checkpoint weights support ranked detection/localization independently
    # of the threshold-selection path, which contains only epoch-200 models.
    d.connector("fixed_to_evaluation",[(254,264),(266,264),(266,398)])
    d.connector("best_to_evaluation",[(391.5,285),(391.5,398),(261.5,398)])
    d.dot(266,398)
    d.arrow("weights_to_test_evaluation",[(261.5,398),(261.5,414)])
    d.box("test_evaluation",140,414,243,44,["Test evaluation","Detection / localization: 45 runs","Locked-threshold screening: 40 runs"],size=9.0,lineheight=12)
    d.arrow("thresholds_to_screening",[(135,384),(122,384),(122,436),(140,436)])
    d.arrow("test_images_to_evaluation",[(433,130),(522,130),(522,436),(383,436)])
    d.box("detection_localization",16,483,238,62,["Detection and localization","AP50, AP75, AP50–95: full ranking","IoU comparisons: confidence 0.25"],size=9,lineheight=12)
    d.box("screening",276,483,231,62,["Defect screening","Precision, recall, F1, FP and FN","Validation-locked operating points"],size=9,lineheight=12)
    d.connector("test_results_branch",[(135,471),(391.5,471)])
    d.connector("evaluation_to_results",[(261.5,458),(261.5,471)])
    d.dot(261.5,471)
    d.arrow("test_to_detection",[(135,471),(135,483)])
    d.arrow("test_to_screening",[(391.5,471),(391.5,483)])
    d.box("paired_statistics",140,570,243,34,["Seed-paired differences and 95% intervals","Five seeds; primary and sensitivity analyses"],size=9,lineheight=11.5)
    d.connector("results_join",[(135,558),(391.5,558)])
    d.connector("detection_to_statistics",[(135,545),(135,558)])
    d.connector("screening_to_statistics",[(391.5,545),(391.5,558)])
    d.dot(261.5,558)
    d.arrow("joined_results_to_statistics",[(261.5,558),(261.5,570)])
    d.export()


if __name__ == "__main__":
    OUT.mkdir(parents=True,exist_ok=True)
    experiment()
    print("Created the experimental workflow and 600-dpi exports.")
